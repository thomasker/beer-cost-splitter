// 🍺 Beer Cost Splitter App - Multi-Page Modular Edition with Routing
import { useState } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from 'react-router-dom';

function AddBeerForm({ beers, setBeers }) {
  const [beerName, setBeerName] = useState('');
  const [beerCost, setBeerCost] = useState('');
  const [beerVolume, setBeerVolume] = useState('');

  const addBeer = () => {
    if (!beerName || !beerCost || !beerVolume) return;
    setBeers([...beers, {
      name: beerName,
      cost: parseFloat(beerCost),
      volume: parseFloat(beerVolume)
    }]);
    setBeerName('');
    setBeerCost('');
    setBeerVolume('');
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Add a Beer</h2>
      <input placeholder="Beer Name" value={beerName} onChange={e => setBeerName(e.target.value)} />
      <input placeholder="Total Cost (€)" type="number" value={beerCost} onChange={e => setBeerCost(e.target.value)} />
      <input placeholder="Total Volume (L)" type="number" value={beerVolume} onChange={e => setBeerVolume(e.target.value)} />
      <button onClick={addBeer}>Add Beer</button>
      <div>
        {beers.map((b, i) => (
          <div key={i}>{b.name}: €{b.cost} for {b.volume}L</div>
        ))}
      </div>
    </div>
  );
}

function AddDrinkerForm({ beers, drinkers, setDrinkers }) {
  const [name, setName] = useState('');
  const [selectedBeer, setSelectedBeer] = useState('');
  const [amount, setAmount] = useState('');

  const addDrinker = () => {
    if (!name || !selectedBeer || !amount) return;
    setDrinkers([...drinkers, {
      name,
      beer: selectedBeer,
      amount: parseFloat(amount),
      timestamp: new Date().toISOString()
    }]);
    setName('');
    setSelectedBeer('');
    setAmount('');
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Add Drinker</h2>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
      <select value={selectedBeer} onChange={e => setSelectedBeer(e.target.value)}>
        <option value="">Select Beer</option>
        {beers.map((b, i) => (
          <option key={i} value={b.name}>{b.name}</option>
        ))}
      </select>
      <input placeholder="Amount (L)" type="number" value={amount} onChange={e => setAmount(e.target.value)} />
      <button onClick={addDrinker}>Add Drinker</button>
      <div>
        {drinkers.map((d, i) => (
          <div key={i}>{d.name} drank {d.amount}L of {d.beer} at {new Date(d.timestamp).toLocaleString()}</div>
        ))}
      </div>
    </div>
  );
}

function Summary({ beers, drinkers }) {
  const calculateOwed = () => {
    const summary = {};

    drinkers.forEach(d => {
      const beer = beers.find(b => b.name === d.beer);
      const costPerLiter = beer ? beer.cost / beer.volume : 0;
      const owed = d.amount * costPerLiter;

      if (!summary[d.name]) {
        summary[d.name] = { total: 0, beers: {} };
      }

      summary[d.name].total += owed;
      summary[d.name].beers[d.beer] = (summary[d.name].beers[d.beer] || 0) + d.amount;
    });

    return summary;
  };

  const results = calculateOwed();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Summary</h2>
      {Object.entries(results).map(([person, data], i) => (
        <div key={i}>
          <strong>{person}</strong> owes €{data.total.toFixed(2)}
          <ul>
            {Object.entries(data.beers).map(([beerName, qty], j) => (
              <li key={j}>{qty}L of {beerName}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default function BeerSplitter() {
  const [beers, setBeers] = useState([]);
  const [drinkers, setDrinkers] = useState([]);

  return (
    <Router>
      <div>
        <h1>🍻 Beer Cost Splitter</h1>
        <nav>
          <Link to="/">Add Beer</Link> | <Link to="/drinkers">Add Drinker & Summary</Link>
        </nav>
        <Routes>
          <Route path="/" element={<AddBeerForm beers={beers} setBeers={setBeers} />} />
          <Route path="/drinkers" element={
            <>
              <AddDrinkerForm beers={beers} drinkers={drinkers} setDrinkers={setDrinkers} />
              <Summary beers={beers} drinkers={drinkers} />
            </>
          } />
        </Routes>
      </div>
    </Router>
  );
}
